package com.iktpreobuka.classmate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClassmateApplicationTests {

	@Test
	void contextLoads() {
	}

}
