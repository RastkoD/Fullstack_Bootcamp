package com.iktpreobuka.classmate.entities.enums;

public enum GradeEnum {
	I, II, III, IV, V, VI, VII, VIII
}
