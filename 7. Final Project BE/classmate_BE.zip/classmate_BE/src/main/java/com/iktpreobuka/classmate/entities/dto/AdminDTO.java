package com.iktpreobuka.classmate.entities.dto;

public class AdminDTO {

}
