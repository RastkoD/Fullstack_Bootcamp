package com.iktpreobuka.classmate.services;

import java.io.File;

public interface FileHandler {

	File getLogs();
}
