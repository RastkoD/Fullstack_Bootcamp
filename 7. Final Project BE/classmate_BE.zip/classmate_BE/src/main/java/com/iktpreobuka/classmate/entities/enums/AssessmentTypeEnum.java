package com.iktpreobuka.classmate.entities.enums;

public enum AssessmentTypeEnum {
	ORAL, TEST, ESSAY, PARTICIPATION, HOMEWORK, OTHER, FINAL
}
