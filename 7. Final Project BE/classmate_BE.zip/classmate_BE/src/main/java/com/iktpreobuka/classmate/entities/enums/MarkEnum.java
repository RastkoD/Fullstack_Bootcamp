package com.iktpreobuka.classmate.entities.enums;

public enum MarkEnum {
	INSUFFICIENT, SUFFICIENT, GOOD, VERY_GOOD, EXCELLENT
}
