package com.iktpreobuka.classmate.entities.enums;

public enum TermNameEnum {
	FIRST, SECOND
}
