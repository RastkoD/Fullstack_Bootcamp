/* 
    Zadatak 2
    Prošriti funkciju iz zadatka 1 tako da ne sortira samo brojeve u uzlaznom redosledu nego može da sortira bilo šta kroz komparatorsku funkciju koja vraća, za neko a i b, -1 kada a < b, 0 kada a == b, i 1 kada a > b. Takva funkcija za sortiranje dobija niz i funkciju. Testirati ovu funkciju tako što joj se da niz i funkcija koja sortira u silazećem redosledu. Inače, svaki niz ima funkciju .sort koja obavlja tačno ovaj posao koji ovde kodiramo, i prima kao parametar komparatorsku funkciju koja radi tačno kao ova koju opisujemo ovde. 
*/

const JSV2 = () => {
  //const arr = [4, 18, 33, 5, 11, 22, 88, 67];
  //console.log("Array:", arr);

  const arr = ["banana", "apple", "orange", "grape"];
  console.log("String Array:", arr);

  function sorting(arr, comparatorFunction) {
    return arr.sort(comparatorFunction);
  }

  function descComparator(a, b) {
    if (a < b) return 1;
    if (a > b) return -1;
    return 0;
  }

  //const sortedArr = sorting(arr, descComparator);
  //console.log("Sorted array:", sortedArr);

  const sortedArr = sorting(arr, descComparator);
  console.log("Sorted String Array:", sortedArr);

  const sortedElements = sortedArr.map((e) => <h2 key={e}>{e}</h2>);

  return <div>{sortedElements}</div>;
};

export default JSV2;
