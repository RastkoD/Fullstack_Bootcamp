/* 
    Zadatak 6
    Napisati funkciju koja računa koliko je dobar pangram neki string. Pangram je rečenica koja ima u sebi sva slova nekog jezika. Ovde nas samo zanima engleksi jezik radi jednostavnosti. Velika i mala slova ignorišemo, baš kao i apsolutno sve što nije slovo. Kvalitet pangrama definiše sledeće pravilo: ako nemamo sva slova, onda je kvalitet 0. Ako imamo sva slova, onda je kvalitet jednak broju slova u azbuci jezika (26 ovde) podeljenom sa brojem slova koji pangram u stvari ima. Savršen pangram (bez ponavljanja) onda ima rezultat 1. 
*/
const evaluate_pangram = (p) => {
  p = p.toLowerCase();
  p = p.replace(/[^a-z]/g, "");
  let arr = p.split("");
  let f = new Map();

  for(let n of arr) {
    if(f.has(n)) {
      f.set(n, f.get(n) + 1);
    } else {
      f.set(n, 1);
    }
  }

  let len = 0;
  for(let k of f.keys()) len++;
  if(len < 26) return 0;
  return 26.0 / arr.length;
}


const JSV6 = () => {
  return <div>
    <ul>
      <li>{evaluate_pangram("Nije pangram")}</li>
      <li>{evaluate_pangram("The quick brown fox jumps over the lazy dog.")}</li>
      <li>{evaluate_pangram("Jackdaws love my big sphinx of quartz.")}</li>
      <li>{evaluate_pangram("Jink cwm, zag veldt, fob Qursh pyx.")}</li>
    </ul>
  </div>;
};

export default JSV6;
