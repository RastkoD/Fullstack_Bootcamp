/* 
    Zadatak 7
    Napisati funkciju koja za dati dan (1-31), mesec (1-12), i godinu (četiri cifre) koji predstavljaju datum rođenja, vrati koliko je osoba rođena na taj dan bila živa, u sekundama. Program ne treba da radi za datume pre 1970. 
*/
function lifeInSeconds(day, month, year) {
  if(year < 1970) {
    return "Program ne treba da radi za datume pre 1970"
  }

  let sd = day.toString();
  if (day < 10) {
    sd = "0" + sd;
  }

  let sm = month.toString();
  if (month < 10) {
    sm = "0" + sm;
  }

  let dat = Date(`${year} - ${month} - ${day}`);
  let now = Date();

  return (now.valueOf() - dat.valueOf()) / 1000.0;
}

const JSV7 = () => {
  return <div>
    {lifeInSeconds(25, 2, 1989)}
  </div>;
};

export default JSV7;
