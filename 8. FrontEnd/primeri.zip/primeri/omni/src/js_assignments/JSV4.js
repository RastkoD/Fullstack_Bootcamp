/* 
    Zadatak 4
    Napisati funkciju koja za dva stringa odredi da li su anagrami ili ne. Razmaci nisu bitni, velika i mala slova nisu bitna, interpunkcija nije podržana.
*/

const is_anagram = (a,b) => {
  const strA = a.replace(/\s/g, '').toLowerCase();
  const strB = b.replace(/\s/g, '').toLowerCase();

  const sortedA = strA.split("").sort().join("");
  const sortedB = strB.split("").sort().join("");

  return sortedA === sortedB;
}

console.log(is_anagram("anagram", "maranag"));

const JSV4 = () => {
  return <div>
  </div>;
};

export default JSV4;
