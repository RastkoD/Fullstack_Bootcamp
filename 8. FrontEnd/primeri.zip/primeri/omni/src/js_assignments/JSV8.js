/* 
    Zadatak 8
    Napisati funkciju koja preuzme funkciju, listu, i naziv i vrati novu funkciju koja se ponaša isto kao i prosleđena funkcija samo što, se u listu upisuje svaki poziv funkcije sa parametrima u obliku stringa koji, ako je funkcija pozvana sa parametrima 3 i 4, recimo, bude "f(3,4)" gde je 'f' štagod da je u nazivu
*/
function boss(minion, list, name) {
  return function(...args) {
    const string = `${name}(${args.join(",")})`;
    list.push(string);

    return minion(...args);
  };
};

const minion = function(a, b) {
  return a + b;
}

const listArr = [];
const funcName = "minionFunction";

const newFunction = boss(minion, listArr, funcName);

const JSV8 = () => {
  return <div>
    <h4>{newFunction(3, 4)}</h4>
    <h4>{listArr}</h4>
  </div>;
};

export default JSV8;
