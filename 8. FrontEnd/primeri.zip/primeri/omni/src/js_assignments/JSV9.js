/* 
    Zadatak 9
    Napisati funkciju koja za dati tekst vrati procenat upotrebe svih slova u redosledu abecede. Mala i velika slova se ignorišu, razmaci i znakovi interpunkcije se ignorišu. Za potrebe ovoga, samo se razmatra engleska abeceda. 
*/

function calcLetterPercent(text) {
  text = text.toLowerCase();

  const letterCounter = {};
  const allLetters = "abcdefghijklmnopqrstuvwxyz";

  for (let letter of allLetters) {
    letterCounter[letter] = 0;
  }

  for (let letter of text) {
    if (allLetters.includes(letter)) {
      letterCounter[letter]++;
    }
  }

  let totalLetters = 0;

  for (let letter in letterCounter) {
    totalLetters += letterCounter[letter];
  }

  let letterPercent = {};

  for (let letter of allLetters) {
    letterPercent[letter] = (letterCounter[letter] / totalLetters) * 100;
  }

  return letterPercent;
}

const JSV9 = () => {
  //patnja
  const letterPercent = calcLetterPercent("Jink cwm, zag veldt, fob Qursh pyx.");
  //const letterPercent = calcLetterPercent("The quick brown fox jumps over the lazy dog, who then barks loudly at the nearby tree.");

  const formattedPercentages = Object.entries(letterPercent)
    .map(([letter, percent]) => `${letter}: ${percent.toFixed(2)}%`)
    .join(", ");

  return (
    <div>
      <h4>{formattedPercentages}</h4>
    </div>
  );
};

export default JSV9;
