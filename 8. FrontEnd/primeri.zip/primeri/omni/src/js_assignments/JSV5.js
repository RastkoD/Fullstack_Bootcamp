/* 
    Zadatak 5
    Napisati funkciju koja za dati string kaže da li je palindrom (čita se isto i sa jedne i sa druge strane). Razmaci i mala/velika slova nisu bitni, a interpunkcija nije podržana. 
*/

const is_palindrome = (s) => {
  let toLowerStr = s.toLowerCase().replace(/\s/g, "");

  let reverseStr = toLowerStr.split("").reverse().join("");

  if(reverseStr === toLowerStr) {
    return true;
  } else {
    return false;
  }
}

const testPali = "ana voli milovana";
console.log(`Is "${testPali}" a palindrome?`, is_palindrome(testPali));

const JSV5 = () => {
  return <div>
  </div>;
};

export default JSV5;
