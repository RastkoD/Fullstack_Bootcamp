/* 
    Zadatak 1
    Napiši funkciju koja prima ulazni niz proizvoljne dužine i sortira ga. 
*/

const zad1 = () => {
  const arr = [4, 18, 33, 5, 11, 22, 88, 67];
  console.log("Array:", arr);

  function sorting(arr) {
    return arr.sort((a, b) => a - b);
  }

  const sortedArr = sorting(arr);
  console.log("Sorted array:", sortedArr);

  // Zadatak 1. Proći kroz niz elemenata i ispisati sve parne elementa.
  const evenNumbers = [];

  arr.filter((x) => x % 2 === 0).forEach((x) => evenNumbers.push(x));

  console.log("Even numbers of the array:", evenNumbers);

  // Zadatak 1.1. Dodati pronađene parne elemente u novi niz elemenata i ispisati taj novi niz

  // Zadatak 1.2. Dodati pronađene parne elemente u novi niz elemenata ali u suprotnom redosledu
  const evenNumbersReversed = evenNumbers.reverse();

  console.log(
    "Even numbers of the array in reverse order:",
    evenNumbersReversed
  );
};

const zad3 = () => {
  /*Napraviti mini program za logovanje korisnika. Korisnika predstaviti kao objekat koji
ima atribute: ime, prezime, korisničko ime i šifru. Sve korisnike smestiti u mapu gde
je ključ korisničko ime, a vrednost objekat koji predstavlja korisnika. Zatim napraviti
dve promenljive koje predstavljaju korisničko ime i lozinku i dodeliti im neku vrednost.
Na osnovu korisničkog imena i lozinke pokušati da ulogujete korisnika, ako je
logovanje uspešno ispisati podatke o korisniku, a ako nije napisati poruku ‚‚Pogrešno
korisničko ime ili šifra‚‚.*/
  const users = new Map();
  const u1 = {
    name: "Frodo",
    lastName: "Baggins",
    username: "myPrecious",
    password: "rulethemall",
  };
  const u2 = {
    name: "Samwise",
    lastName: "Gamgee",
    username: "Gardener",
    password: "realhero",
  };
  const u3 = {
    name: "Meriadoc",
    lastName: "Brandybuck",
    username: "RiderOfRohan",
    password: "pipandme",
  };

  users.set(u1.username, u1);
  users.set(u2.username, u2);
  users.set(u3.username, u3);

  let username = "Gardener";
  let password = "realhero";

  if (users.has(username)) {
    let user = users.get(username);

    if (user.password === password) {
      console.log(`User logged in: ${user.name} ${user.lastName}`);
    } else {
      console.log("Wrong username or password");
    }
  } else {
    console.log("User not found");
  }
};

const zad4 = () => {
  /*
    Od niza elemenata napraviti dva niza. Jedan niz treba da budu elementi koji se
    nalaze na parnim indeksima a njihova vrednost je neparan broj, a drugi elementi koji
    se nalaze na neparnim indeksima a njihova vrednost je paran broj.
  */
  const arr = [1, 2, 3, 4, 5, 6, 7, 8, 9];

  const evenIndexOddNumber = [];
  const oddIndexEvenNumber = [];

  arr
    .filter((x) => x % 2 !== 0 && arr[x] % 2 === 0)
    .forEach((x) => evenIndexOddNumber.push(x));

  arr
    .filter((x) => x % 2 === 0 && arr[x] % 2 !== 0)
    .forEach((x) => oddIndexEvenNumber.push(x));

  console.log(`Even index and odd number: ${evenIndexOddNumber}`);
  console.log(`Odd index and even number: ${oddIndexEvenNumber}`);
};

const zad5 = () => {
  /*
    Iz sledećeg teksta pomoću regularnog izraza izdvojiti sve e-mail adrese.
    Tekst: Petar Petrović ima naloge na nekoliko servisa koji omogućavaju razmenu
    poruka. Njegove adrese su pera.petrovic@gmail.com, petar@uns.ac.rs i
    petrovic@yahoo.com. Mina Mirković takođe ima nekoliko e-mail adresa. Za
    komunikaciju sa Petrom koristi adresu mina90.m@hotmail.com.
  */

  const text =
    "Petar Petrović ima naloge na nekoliko servisa koji omogućavaju razmenu poruka. Njegove adrese su pera.petrovic@gmail.com, petar@uns.ac.rs i petrovic@yahoo.com. Mina Mirković takođe ima nekoliko e-mail adresa. Za komunikaciju sa Petrom koristi adresu mina90.m@hotmail.com.";

  const emailFinder = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;

  const emails = text.match(emailFinder);

  console.log(emails);
};

const zad6 = () => {
  /*
    Napraviti program koji na osnovu podataka o pravougaoniku računa: dijagonalu,
    stranice pravougaonika, površinu i obim. Pravougaonik je predstavljen kao objekat
    koji za atribute ima koordinate temena. Koristiti destrukturiranje podataka.
    Primer:
  */

  let pravougaonik = {
    A: { x: 10, y: 30 },
    B: { x: 30, y: 30 },
    C: { x: 30, y: 45 },
    D: { x: 10, y: 45 },
  };

  function calcDiag({ A, C }) {
    const x = C.x - A.x;
    const y = C.y - A.y;

    return Math.sqrt(x ** 2 + y ** 2);
  }

  function calcSides({ A, B, C, D }) {
    const AB = Math.sqrt((B.x - A.x) ** 2 + (B.y - A.y) ** 2);
    const BC = Math.sqrt((C.x - B.x) ** 2 + (C.y - B.y) ** 2);
    const CD = Math.sqrt((D.x - C.x) ** 2 + (D.y - C.y) ** 2);
    const DA = Math.sqrt((A.x - D.x) ** 2 + (A.y - D.y) ** 2);

    return { AB, BC, CD, DA };
  }

  function calcArea({ AB, BC }) {
    return AB * BC;
  }

  function calcPerimeter({ AB, BC }) {
    return 2 * (AB + BC);
  }

  const diagonal = calcDiag(pravougaonik);
  const sides = calcSides(pravougaonik);
  const area = calcArea(sides);
  const perimeter = calcPerimeter(sides);

  console.log(`Diagonal: ${diagonal}`);
  console.log(
    `Sides: AB = ${sides.AB}, BC = ${sides.BC}, CD = ${sides.CD}, DA = ${sides.DA}`
  );
  console.log(`Area: ${area}`);
  console.log(`Perimeter: ${perimeter}`);
};

const zad7 = () => {
  // Za dati niz elemenata izračunati: zbir, srednju vrednost i proizvod.
  const arr = [4, 18, 33, 5, 11, 22, 88, 67];
  /*
  const sumOfArr = (nums) => {
    let sum = 0;

    for(let n of nums) {
      sum += n;
    }

    return sum;
  }
  */
  const sumOfArr = (nums) => {
    return nums.reduce((a, b) => a + b, 0);
  };

  const multiOfArrNums = (nums) => {
    return nums.reduce((a, b) => a * b, 1);
  };

  const arrSum = sumOfArr(arr);
  const arrMulti = multiOfArrNums(arr);
  const arrAverage = arrSum / arr.length;

  console.log(`Sum of array elements is: ${arrSum}`);
  console.log(`Multiplication of array elements is: ${arrMulti}`);
  console.log(`Average of array elements is: ${arrAverage}`);
};

const zad8 = () => {
  /*
    Za dati niz elemenata pronaći element u nizu koji se najčešće pojavljuje.
    Primer niza:  */

  const arr1 = [3, "a", "a", "a", 2, 3, "a", 3, "a", 2, 4, 9, 3];

  const findMostFrequentElement = (arr) => {
    const elementCount = {};

    arr.forEach((element) => {
      if (elementCount[element]) {
        elementCount[element]++;
      } else {
        elementCount[element] = 1;
      }
    });

    let mostFrequentElement;
    let count = 0;

    for (const element in elementCount) {
      if (elementCount[element] > count) {
        mostFrequentElement = element;
        count = elementCount[element];
      }
    }

    return mostFrequentElement;
  };

  const mostFrequent = findMostFrequentElement(arr1);

  console.log(`Most frequent element is: ${mostFrequent}`);
};

const zad9 = () => {
  /*
    Proći kroz dati niz elemenata i ispisati imena i prezimena studenata.*/
  let studenti = [
    { indeks: "XY 409/2072", ime: "Alice", prezime: "Alferson" },
    { indeks: "ZW 133/2072", ime: "Bob", prezime: "Bobbert" },
    { indeks: "XY 112/2073", ime: "Carol", prezime: "Creed" },
    { indeks: "XY 507/2071", ime: "Drew", prezime: "Danger" },
    { indeks: "ZW 233/2070", ime: "Eve", prezime: "Emmerson" },
    { indeks: "ZW 57/2072", ime: "Trent", prezime: "Tweed" },
    { indeks: "XY 111/2071", ime: "Fred", prezime: "Franks" },
    { indeks: "ZW 404/2073", ime: "George", prezime: "Green" },
  ];

  studenti.forEach((student) => {
    console.log(`Name: ${student.ime}, Lastname: ${student.prezime}`);
  });
};

const zad10 = () => {
  /*
    Ispisati sve stringove koji se pojavljuju u sledećem nizu elemenata: [1, 34, ‘1’, ‘abc’, 347, ‘false’, ‘s’, 123]
  */
  const arr = [1, 34, "1", "abc", 347, "false", "s", 123];

  arr.forEach((element) => {
    if(typeof(element) === "string") {
      console.log(element);
    }
  })

};

const JSV1 = () => {
  return <div>{zad10()}</div>;
};

export default JSV1;
