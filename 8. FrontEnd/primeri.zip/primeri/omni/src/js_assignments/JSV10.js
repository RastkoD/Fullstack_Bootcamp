import React, { useState, useEffect } from 'react';
/* 
    Napisati program koji dobije početnu poziciju (kao x i y) i orijentaciju (N, S, W, E) Lengtonovog mrava https://en.wikipedia.org/wiki/Langton%27s_ant (videti i na slajdovima) i broj generacija i vrati poziciju i orijentaciju mrava posle toliko generacija. 

    Pravila Lengtonovog mrava (za nas):
    1. Svet je beskonačna 2D ravan podeljena na kvadrate jednake veličine koji mogu biti beli ili crni. 
    2. Negde u svetu je mrav. Mrav ima poziciju i rotaciju. 
    3. U svakom potezu (ili generaciji) mrav prati sledeća pravila:
        a. Ako stoji na polju koje je belo, mrav se okrene za 90 stepeni u smeru kazaljke na satu, promeni boju ispod sebe iz bele u crnu i pomeri se napred za jedan korak. 
        b. Ako stoji na polju koje je crno, mrav se okrene za 90 stepeni u smeru suprotnom od kazaljke na satu, promeni boju ispod sebe iz crne u belu i pomeri se napred za jedan korak.
    4. Na početku igre, ceo svet je crn. 

    Lengtonov mrav je primer teoretske tvorevine poznate kao 'ćelijski automat' i ima kolosalan značaj u teoretskim računarskim naukama. Za nas je to odlična vežba veštine programiranja. 
*/
const LangtonsAnt = ({startX, startY, startOrientation, generations}) => {
  let [position, setPosition] = useState({x: startX, y: startY});
  let [orientation, setOrientation] = useState(startOrientation);
  let [world, setWorld] = useState({});

  const rotation = (direction) => {
    const orientations = ["N", "E", "S", "W"];
    let currentIndex = orientations.indexOf(orientation);
    let newIndex;
    
    if(direction === "right") {
      newIndex = (currentIndex + 1) % orientations.length;
    } else {
      newIndex = (currentIndex - 1 + orientations.length) % orientations.length;
    };
    
    setOrientation(orientations[newIndex]);
  };

  const move = () => {
    let {x, y} = position;
//nisam sasvim siguran u ++ i --
    switch(orientation) {
      case "N":
        y++;
        break;
      case "E":
        x++;
        break;
      case "S":
        y--;
        break;
      case "W":
        x--;
        break;;
      default:
        break;
    }

    setPosition({x, y});
  };

  const toggleColourAndRotateAnt = () => {
    let key = `${position.x}, ${position.y}`;
    let newWorld = {...world};

    if(world[key] === "black") {
      newWorld[key] = "white";
      
      rotation("left");
    } else {
      newWorld[key] = "black";
      rotation("right");
    };

    setWorld(newWorld);
  };

  const generationTurn = () => {
    toggleColourAndRotateAnt();
    move();
  };

  useEffect(() => {
    let initialWorld = { [`${startX},${startY}`]: "black" };
    setWorld(initialWorld);

    let generation = 0;
    let interval = setInterval(() => {
      generationTurn();
      generation++;

      if(generation === generations) clearInterval(interval);
    }, 500);

    return () => clearInterval(interval);
  }, []);

  return (
    <div>
      <p>Position: ({position.x}, {position.y})</p>
      <p>Orientation: {orientation}</p>
    </div>
  );

};

function JSV10() {
  return (
    <div>
      <h1>Lentgons Ant</h1>
      <LangtonsAnt startX = {0} startY = {0} startOrientation = "S" generations = {1265} />
    </div>
  )
}

export default JSV10;
