import React from "react";
import BookItem from "./BookItem";
import { useLoaderData } from "react-router-dom";

const BookList = () => {
  const data = useLoaderData();

  return (
    <div>
      <h1>Books</h1>
      <ul>
        {data.map((v) => (
          <BookItem key={v.id} book={v} />
        ))}
      </ul>
    </div>
  );
};

export default BookList;
