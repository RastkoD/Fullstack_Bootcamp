import React from 'react'
import { useLoaderData } from 'react-router-dom'
import { useImmer } from 'use-immer';

const BookDetails = (props) => {
  const data = useLoaderData();
  
  const [book, setBook] = useImmer(data);
  return (
    <div>
      <label>Title: <input type="text" value={book.title} onChange={(e) => {
        setBook(b => { b.title = e.target.value });
      }}></input></label>
      <button onClick={async () => {
        let response = await fetch(`http://localhost:8080/api/v1/book/${book.id}`, {
          method: "PUT",
          headers: {
              "Content-Type": "application/json",
          },
          body: JSON.stringify(book),
      });
      if(response.ok){
          let d = await response.json();
          console.log(JSON.stringify(d, null, 4));
      }else{
          console.log("Neuspeh slanja!");
      }
      }}>Save</button>
    </div>
  )
}

export default BookDetails