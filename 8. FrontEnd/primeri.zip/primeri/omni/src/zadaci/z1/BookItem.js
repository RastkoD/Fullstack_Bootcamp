import React from "react";
import { Link } from "react-router-dom";

const BookItem = (props) => {
  return <li className="booksLinkDetails">{props.book.title} <Link to={`book_details/${props.book.id}`}>Details</Link></li>;
};

export default BookItem;
