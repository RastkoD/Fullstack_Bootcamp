/*
    Napraviti stranicu koja odgovara primeru koji je dat.
    Slika je dostupna na sledećem linku: https://www.logo.wine/logo/Apache_Tomcat
*/
import slika from "./../assets/images/zad7.png";
import "./zadatak7.css";

const Zadatak_J7 = () => {
  return (
    <div>
      <h2> Zadatak 7</h2>
      <div className="zad7_container">
        <div>
          <p> Prikazati tekst kao što je na slici: </p>
          <img src={slika} />
        </div>
        <p> TO DO:</p>
        <main className="readerMain">
          <h1>Web citaci</h1>
          <p>Web citac je aplikacija koja je namenjena prikazu sadrzaja web stranica.</p>
          <p>Stranice se mogu dobaviti kako iz fajl-sistema, tako i putem TCP/IP mreze. Protokol kojim komuniciraju web citac i web server je HTTP protokol.</p>
          <p>Danas su najpoznatiji sledeci web citaci:</p>
          <ol>
            <li><a href="https://www.microsoft.com/en-us/edge" target="_blank">Microsoft Edge</a></li>
            <li><a href="https://www.google.com/chrome/" target="_blank">Google Chrome</a></li>
            <li><a href="https://www.mozilla.org/en-US/" target="_blank">Mozilla</a></li>
          </ol>
          <img src="https://www.logo.wine/a/logo/Apache_Tomcat/Apache_Tomcat-Logo.wine.svg"
          alt="apache tomcat logo"
          className="readerImg"
           />
        </main>
      </div>
    </div>
  );
};

export default Zadatak_J7;
