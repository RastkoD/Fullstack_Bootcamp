// Prikazati stihove naredne pesme:
/*
My Bonnie lies over the ocean
My Bonnie lies over the sea
My Bonnie lies over the ocean
Oh, bring back my Bonnie to me.
*/

// Iznad stihova napisati naslov pesme: "Poem" i odvojiti horizontalnom linijom od stihova
import "./zadatak8.css";

const Zadatak_J8 = () => {
  // to do
  return (
    <>
      {" "}
      <div>Zadatak 8</div>
      <main className="songMain">
        <section>
          <h3>Poem</h3>
          <hr />
          <em className="song">
            My Bonnie lies over the ocean
            <br />
            My Bonnie lies over the sea <br />
            My Bonnie lies over the ocean <br />
            Oh, bring back my Bonnie to me.
            <br />
          </em>
        </section>
      </main>
    </>
  );
};

export default Zadatak_J8;
