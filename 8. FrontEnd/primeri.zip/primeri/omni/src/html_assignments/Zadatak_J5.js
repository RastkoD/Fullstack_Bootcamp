/*
Kreirati formu za prijavu kandidata za posao. Izgled forme je dat na slici
*/

import slika from "./../assets/images/zad5.PNG";
import "./zadatak5_css.css";
const Zadatak_J5 = () => {
  return (
    <div>
      <h2> Zadatak 5</h2>
      <div className="zad5_container">
        <div>
          <p> Slika na osnovu koje treba napraviti formu</p>
          <img src={slika} />
        </div>
        <div>
          {/* to do: ovde kreirati formu */}
          <p> TO DO: FORMA</p>
          <section className="form">
            <div className="formSection">
              <div className="formHeading">
                <div className="formHeadingNumber">1</div>
                <h4>Candidate Info</h4>
              </div>
              <input type="text" placeholder="Your Name *"></input>
              <input type="email" placeholder="Your Email *"></input>
              <textarea placeholder="About Yourself"></textarea>
            </div>
            <div className="formSection">
              <h6>Interests:</h6>
              <select name="Interests">
                <option value="Fishkeeping">Fishkeeping</option>
                <option value="Boxing">Boxing</option>
                <option value="Cooking">Cooking</option>
                <option value="Dogs">Dogs</option>
              </select>
            </div>
            <div className="formSection">
              <div className="formHeading">
                <div className="formHeadingNumber">2</div>
                <h4>Additional Info</h4>
              </div>
              <textarea placeholder="About Your School"></textarea>
            </div>
            <button className="formBtn">Apply</button>
          </section>
        </div>
      </div>
    </div>
  );
};

export default Zadatak_J5;
