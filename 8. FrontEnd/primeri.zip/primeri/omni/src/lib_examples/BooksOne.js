import React from "react";

const BooksOne = ({ knjiga }) => {
  return (
    <div className="knjiga">
      <h4>{knjiga.title}</h4>
      <h6>- {knjiga.author}</h6>
      <button>
        <a>Details</a>
      </button>
    </div>
  );
};

export default BooksOne;
