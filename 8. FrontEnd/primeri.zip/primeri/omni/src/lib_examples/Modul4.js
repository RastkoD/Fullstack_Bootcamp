const w = () => {
    return "Module4->W";
}

export default w; //Podrazumevanost se postiže sa sintaksom 'export default' koju prati ona stvar koju hoćemo da bude podrazumevana. 