import React from "react";
import biblioteka from "./biblioteka.json";
import BooksOne from "./BooksOne";

const BooksAll = () => {
  return (
    <div className="biblioteka">
      {biblioteka.map((knjiga) => (
        <BooksOne key={knjiga.id} knjiga={knjiga} />
      ))}
    </div>
  );
};

export default BooksAll;
