export const y = () => {
    return "Module3->F";
}

export const z = () => {
    return "Module3->X";
}