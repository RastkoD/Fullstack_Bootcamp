import React from 'react'
import BooksAll from './BooksAll'

const Books = () => {
  return (
    <BooksAll />
  )
}

export default Books