const PodElement2 = () => {
    return <h2>Ovo je pod element 2!</h2>
}

export default PodElement2;