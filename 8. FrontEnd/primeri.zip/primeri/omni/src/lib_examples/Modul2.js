export const f = () => {
    return "Module2->F";
}

export const x = () => {
    return "Module2->X";
}